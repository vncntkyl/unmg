<article style="padding-left: 1rem; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px;">
    <p style="margin: 0; padding-top: 5px; color: black;">{message}</p>
    <div>
        <p style="color: black;"><span style="font-weight: 600; color: black;">Employee Name: </span><span style="color: black;">{employee_name}</span><br>
            <span style="font-weight: 600; color: black;">Date: </span>{date_submitted}
        </p>
    </div>
    <a href="{link}" style="background-color: #306088; color: white; padding:8px; border-radius: 10px;">{link_message}</a>
</article>