<article style="padding-left: 1rem;">
    <p style="margin: 10px 0; padding: 5px 0; color: black;">{message}</p>
    <div style="display: block; width: 100%; text-align:center;">
        <a href="{link}" style="background-color: #306088; color: white; padding:8px; border-radius: 10px;">{link_message}</a>
    </div>
</article>